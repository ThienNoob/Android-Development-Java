package com.example.qlsv;

public class SinhVien {
    public int MSSV;
    public String Ten;
    public String Dtb;

    public SinhVien(int MSSV, String ten, String dtb) {
        this.MSSV = MSSV;
        Ten = ten;
        Dtb = dtb;
    }
}
